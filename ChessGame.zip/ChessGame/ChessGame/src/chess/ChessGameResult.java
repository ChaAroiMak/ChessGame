package chess;

public enum ChessGameResult {
    OK, win
}
