package Board;

public interface LocalBoardChangeListener {
    /**
     * just a notification that something has changed
     */
    void changed();
}
