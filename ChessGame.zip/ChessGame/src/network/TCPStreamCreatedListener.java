package network;

public interface TCPStreamCreatedListener {
    void streamCreated(TCPStream channel);
}
